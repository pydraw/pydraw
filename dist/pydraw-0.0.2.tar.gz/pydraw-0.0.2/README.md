# pydraw

This is a simple graphics library designed to make graphics
and input simple and synchronized.

It was originally designed to replace turtle as the goto graphics library for teaching
computer science. It has grown into a larger project, with loftier goals of creating an 
easy-to-use library that will be easy to learn, teach, and use in almost any circumstance.