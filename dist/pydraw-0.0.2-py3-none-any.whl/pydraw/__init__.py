from pydraw.color import Color;
from pydraw.location import Location;
from pydraw.screen import Screen;
from pydraw.objects import Object, Rectangle, Oval, Triangle, Polygon, CustomPolygon, Text;
